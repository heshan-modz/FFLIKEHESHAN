CONFIG = {
     "EUROPE": "europe_config.json",
    "IND": "ind_config.json",
    "BR": "br_config.json",

}
